import { useState, useEffect } from 'react';
import { Registration } from './components/Registration';
import { Exam } from './components/Exam';
import { Results } from './components/Results';
import { StudentInfo } from './types';

function App() {
  const [step, setStep] = useState<'register' | 'exam' | 'results'>('register');
  const [studentInfo, setStudentInfo] = useState<StudentInfo | null>(null);
  const [finalAnswers, setFinalAnswers] = useState<Record<number, string>>({});

  useEffect(() => {
    // Disable right click
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Disable copy/cut/paste
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey || e.metaKey) && 
        (e.key === 'c' || e.key === 'v' || e.key === 'x' || e.key === 'a')
      ) {
        e.preventDefault();
      }
    };

    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('copy', handleCopy);
    document.addEventListener('cut', handleCopy);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('cut', handleCopy);
    };
  }, []);

  const handleStartExam = (info: StudentInfo) => {
    setStudentInfo(info);
    setStep('exam');
  };

  const handleFinishExam = (answers: Record<number, string>) => {
    setFinalAnswers(answers);
    setStep('results');
    // Scroll to top
    window.scrollTo(0, 0);
  };

  const handleRestart = () => {
    if (window.confirm("Are you sure you want to restart? All progress will be lost.")) {
      setStep('register');
      setStudentInfo(null);
      setFinalAnswers({});
    }
  };

  return (
    <div className="select-none min-h-screen font-sans antialiased text-gray-900">
      {step === 'register' && (
        <Registration onStart={handleStartExam} />
      )}
      
      {step === 'exam' && studentInfo && (
        <Exam 
          studentInfo={studentInfo} 
          onFinish={handleFinishExam} 
        />
      )}
      
      {step === 'results' && studentInfo && (
        <Results 
          studentInfo={studentInfo} 
          answers={finalAnswers} 
          onRestart={handleRestart} 
        />
      )}
    </div>
  );
}

export default App;
