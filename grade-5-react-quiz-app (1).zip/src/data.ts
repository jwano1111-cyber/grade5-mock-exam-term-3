import { Question } from './types';

export const EXAM_TITLE = "Grade 5 English Mock Exam - Term 3";
export const SCHOOL_NAME = "Abu Tammam School";
export const TEACHER_NAME = "Ahmad Mohammad";
export const EXAM_DURATION = 90 * 60; // 90 minutes in seconds

export const examQuestions: Question[] = [
  // PART 1: VOCABULARY (Questions 1-5)
  // New Word Bank (10 words): picnic, fridge, vegetable, ill, difficult, ride, headache, lunch, test, hurt
  {
    id: 1,
    part: "Part 1: Vocabulary",
    type: "vocabulary",
    instruction: "Drag the correct word from the Word Bank to the blank.",
    question: "We should keep the fresh milk inside the _______ so it stays cold.",
    correctAnswer: "fridge",
    points: 2,
    wordBank: ["picnic", "fridge", "vegetable", "ill", "difficult", "ride", "headache", "lunch", "test", "hurt"],
    blankId: "blank-1"
  },
  {
    id: 2,
    part: "Part 1: Vocabulary",
    type: "vocabulary",
    instruction: "Drag the correct word from the Word Bank to the blank.",
    question: "The math exam was very _______, but I tried my best to answer every question.",
    correctAnswer: "difficult",
    points: 2,
    wordBank: ["picnic", "fridge", "vegetable", "ill", "difficult", "ride", "headache", "lunch", "test", "hurt"],
    blankId: "blank-2"
  },
  {
    id: 3,
    part: "Part 1: Vocabulary",
    type: "vocabulary",
    instruction: "Drag the correct word from the Word Bank to the blank.",
    question: "I have a terrible _______ because I spent too much time looking at the computer screen.",
    correctAnswer: "headache",
    points: 2,
    wordBank: ["picnic", "fridge", "vegetable", "ill", "difficult", "ride", "headache", "lunch", "test", "hurt"],
    blankId: "blank-3"
  },
  {
    id: 4,
    part: "Part 1: Vocabulary",
    type: "vocabulary",
    instruction: "Drag the correct word from the Word Bank to the blank.",
    question: "When the weather is sunny, my family likes to have a _______ in the beautiful park.",
    correctAnswer: "picnic",
    points: 2,
    wordBank: ["picnic", "fridge", "vegetable", "ill", "difficult", "ride", "headache", "lunch", "test", "hurt"],
    blankId: "blank-4"
  },
  {
    id: 5,
    part: "Part 1: Vocabulary",
    type: "vocabulary",
    instruction: "Drag the correct word from the Word Bank to the blank.",
    question: "Every morning, I learn how to _______ my new bike in the garden.",
    correctAnswer: "ride",
    points: 2,
    wordBank: ["picnic", "fridge", "vegetable", "ill", "difficult", "ride", "headache", "lunch", "test", "hurt"],
    blankId: "blank-5"
  },

  // PART 2: GRAMMAR (Questions 6-10)
  {
    id: 6,
    part: "Part 2: Grammar",
    type: "grammar",
    instruction: "Read the text about food and drink. Choose the correct answer (A, B, or C).",
    text: "My family (6) ______ has a big breakfast together on Friday mornings. My mother (7) ______ delicious pancakes for everyone. We don't have (8) ______ orange juice today, so we are drinking water. I like to know how (9) ______ sugar is in my tea because I want to stay healthy. We eat fruit (10) ______ we also eat eggs to have a strong body.",
    question: "Gap (6) - Adverb of frequency",
    options: ["always", "never", "any"],
    correctAnswer: "always",
    points: 2
  },
  {
    id: 7,
    part: "Part 2: Grammar",
    type: "grammar",
    instruction: "Choose the correct answer (A, B, or C).",
    text: "My family (6) ______ has a big breakfast together on Friday mornings. My mother (7) ______ delicious pancakes for everyone. We don't have (8) ______ orange juice today, so we are drinking water. I like to know how (9) ______ sugar is in my tea because I want to stay healthy. We eat fruit (10) ______ we also eat eggs to have a strong body.",
    question: "Gap (7) - Present Simple",
    options: ["cooks", "cook", "cooking"],
    correctAnswer: "cooks",
    points: 2
  },
  {
    id: 8,
    part: "Part 2: Grammar",
    type: "grammar",
    instruction: "Choose the correct answer (A, B, or C).",
    text: "My family (6) ______ has a big breakfast together on Friday mornings. My mother (7) ______ delicious pancakes for everyone. We don't have (8) ______ orange juice today, so we are drinking water. I like to know how (9) ______ sugar is in my tea because I want to stay healthy. We eat fruit (10) ______ we also eat eggs to have a strong body.",
    question: "Gap (8) - Quantifier",
    options: ["any", "some", "a"],
    correctAnswer: "any",
    points: 2
  },
  {
    id: 9,
    part: "Part 2: Grammar",
    type: "grammar",
    instruction: "Choose the correct answer (A, B, or C).",
    text: "My family (6) ______ has a big breakfast together on Friday mornings. My mother (7) ______ delicious pancakes for everyone. We don't have (8) ______ orange juice today, so we are drinking water. I like to know how (9) ______ sugar is in my tea because I want to stay healthy. We eat fruit (10) ______ we also eat eggs to have a strong body.",
    question: "Gap (9) - Countable/Uncountable",
    options: ["much", "many", "some"],
    correctAnswer: "much",
    points: 2
  },
  {
    id: 10,
    part: "Part 2: Grammar",
    type: "grammar",
    instruction: "Choose the correct answer (A, B, or C).",
    text: "My family (6) ______ has a big breakfast together on Friday mornings. My mother (7) ______ delicious pancakes for everyone. We don't have (8) ______ orange juice today, so we are drinking water. I like to know how (9) ______ sugar is in my tea because I want to stay healthy. We eat fruit (10) ______ we also eat eggs to have a strong body.",
    question: "Gap (10) - Conjunction",
    options: ["and", "but", "or"],
    correctAnswer: "and",
    points: 2
  },

  // PART 3A: READING TEXT 1 (Questions 11-16)
  {
    id: 11,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Read the text. Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "The food festival was held outdoors because of the good weather.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "True",
    points: 4
  },
  {
    id: 12,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "The writer's father bought fresh vegetable salad.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "False",
    points: 4
  },
  {
    id: 13,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "The fruit salad contained apples and bananas.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "True",
    points: 4
  },
  {
    id: 14,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "Amna thought the honey dates were spicy.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "False",
    points: 4
  },
  {
    id: 15,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "The family sat on chairs to eat their lunch.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "False",
    points: 4
  },
  {
    id: 16,
    part: "Part 3A: Reading Text 1",
    type: "reading-tfn",
    passageId: "reading1",
    instruction: "Choose True, False or Not Given.",
    text: "Last weekend, my family and I had a wonderful time at the local food festival. The weather was perfect for an outdoor event. We saw many stalls selling different types of delicious food from all over the world.\n\nMy father bought some spicy meat sandwiches, while my mother preferred a fresh vegetable salad. I chose a large bowl of fruit salad with grapes, apples, and bananas. We also drank some cold orange juice because it was quite warm. My younger sister, Amna, wanted to try the traditional honey dates, which she said were very sweet.\n\nWe sat on the green grass and enjoyed our lunch together. In the afternoon, we watched a chef show the audience how to cook healthy soup in a big kitchen on the stage. It was a very interesting day, and we learned that eating fresh food is better than buying fast food from the mall.",
    question: "The chef cooked the healthy soup in the morning.",
    options: ["True", "False", "Not Given"],
    correctAnswer: "False",
    points: 4
  },

  // PART 3B: READING TEXT 2 (Questions 17-23)
  {
    id: 17,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Read the text. Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "How many hours of sleep do children need according to doctors?",
    options: ["Seven hours", "Nine hours", "Twelve hours"],
    correctAnswer: "Nine hours",
    points: 4
  },
  {
    id: 18,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "What is a better activity than playing video games all day?",
    options: ["Watching television", "Riding a bike", "Sleeping in the afternoon"],
    correctAnswer: "Riding a bike",
    points: 4
  },
  {
    id: 19,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "Why should students stay physically active?",
    options: ["To make their heart strong", "To learn how to cook", "To win a video game"],
    correctAnswer: "To make their heart strong",
    points: 4
  },
  {
    id: 20,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "What should you use to wash your hands to stay healthy?",
    options: ["Only water", "Soap", "Fruit juice"],
    correctAnswer: "Soap",
    points: 4
  },
  {
    id: 21,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "How does getting enough sleep help children according to the text?",
    options: ["To help their brains grow", "To help them run faster", "To make them hungry"],
    correctAnswer: "To help their brains grow",
    points: 4
  },
  {
    id: 22,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "What should students drink instead of sugary soda?",
    options: ["Milk", "Water", "Fruit juice"],
    correctAnswer: "Water",
    points: 4
  },
  {
    id: 23,
    part: "Part 3B: Reading Text 2",
    type: "reading-abc",
    passageId: "reading2",
    instruction: "Choose A, B or C.",
    text: "Developing healthy habits is essential for students to feel their best and succeed in school. One of the most important habits is getting enough sleep every night. Doctors say children need about nine hours of rest to help their brains grow.\n\nAnother key habit is staying active. Instead of sitting and playing video games all afternoon, you should try to ride a bike or play football in the park with friends. Physical activity makes your heart strong and gives you more energy.\n\nYou should also remember to drink plenty of water throughout the day. Water is much better for your body than sugary soda. Finally, keeping your hands clean by washing them with soap helps you avoid getting ill.\n\nWhen we practice these simple habits every day, we feel happier and our bodies stay strong. It is never too difficult to start making healthy choices for a better and brighter future.",
    question: "What is the overall meaning of this passage?",
    options: ["The importance of healthy habits", "How to play football", "Why we like video games"],
    correctAnswer: "The importance of healthy habits",
    points: 4
  },

  // PART 3C: READING TEXT 3 (Questions 24-30)
  {
    id: 24,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Read the text. Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "Where did the fifth-grade students go on their school trip?",
    options: ["The National Science Museum", "The local park", "The city zoo"],
    correctAnswer: "The National Science Museum",
    points: 4
  },
  {
    id: 25,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "What time did the students leave school on the bus?",
    options: ["At seven o'clock", "At eight o'clock", "At nine o'clock"],
    correctAnswer: "At eight o'clock",
    points: 4
  },
  {
    id: 26,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "What did the students see when they arrived at the museum?",
    options: ["Real dinosaurs", "Giant models of space rockets", "A big yellow bus"],
    correctAnswer: "Giant models of space rockets",
    points: 4
  },
  {
    id: 27,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "What did the students do in the 'Tech World' section?",
    options: ["Used a computer to drive a car", "Built a space rocket", "Ate their lunch"],
    correctAnswer: "Used a computer to drive a car",
    points: 4
  },
  {
    id: 28,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "What did the writer have for lunch at the museum garden?",
    options: ["Fruit salad", "Cheese sandwiches", "Meat and rice"],
    correctAnswer: "Cheese sandwiches",
    points: 4
  },
  {
    id: 29,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "Where did the students watch a short film about the stars?",
    options: ["In the museum garden", "On the yellow bus", "In the planetarium"],
    correctAnswer: "In the planetarium",
    points: 4
  },
  {
    id: 30,
    part: "Part 3C: Reading Text 3",
    type: "reading-abc",
    passageId: "reading3",
    instruction: "Choose A, B or C.",
    text: "Last Tuesday, the fifth-grade students went on an exciting school trip to the National Science Museum. We arrived at school early and boarded a big yellow bus at eight o'clock. Our teacher, Mr. Ahmed, reminded us to be safe and stay together.\n\nWhen we arrived, we saw many giant models of dinosaurs and space rockets. My friend, Khalid, was amazed by the huge skeleton of a T-Rex. We also visited the 'Tech World' section where we could use a computer to simulate driving a car. It was quite difficult but very fun!\n\nAt midday, we went to the museum garden for lunch. I had some cheese sandwiches and a bottle of water. After lunch, we watched a short film about the stars in a round room called the planetarium. We returned to school by three o'clock. I was a bit tired but very happy because I learned many new things about science and history with my classmates.",
    question: "What is the overall meaning of this text?",
    options: ["Learning how to drive", "A fun and educational school trip", "Building dinosaur models"],
    correctAnswer: "A fun and educational school trip",
    points: 4
  }
];
