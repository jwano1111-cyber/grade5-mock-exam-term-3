export type QuestionType = 'vocabulary' | 'grammar' | 'reading-tfn' | 'reading-abc';

export interface Question {
  id: number;
  part: string;
  type: QuestionType;
  instruction: string;
  text?: string;
  passageId?: string;
  question?: string;
  options?: string[];
  correctAnswer: string;
  points: number;
  wordBank?: string[];
  blankId?: string; // For DnD
}

export interface StudentInfo {
  name: string;
  grade: string;
  section: string;
  idNumber: string;
}

export interface ExamState {
  currentQuestionIndex: number;
  answers: Record<number, string>;
  flagged: number[];
  isSubmitted: boolean;
  timeLeft: number;
  startTime: number | null;
}
