import { motion } from 'framer-motion';
import { examQuestions, SCHOOL_NAME } from '../data';
import { StudentInfo } from '../types';
import { 
  Trophy, 
  CheckCircle2, 
  XCircle, 
  RefreshCw,
  Award,
  BarChart3
} from 'lucide-react';

interface ResultsProps {
  studentInfo: StudentInfo;
  answers: Record<number, string>;
  onRestart: () => void;
}

export const Results: React.FC<ResultsProps> = ({ studentInfo, answers, onRestart }) => {
  const calculateResults = () => {
    let score = 0;
    let correct = 0;
    let totalPoints = 0;
    
    const breakdown = examQuestions.map(q => {
      const isCorrect = answers[q.id] === q.correctAnswer;
      totalPoints += q.points;
      if (isCorrect) {
        score += q.points;
        correct += 1;
      }
      return {
        ...q,
        isCorrect,
        studentAnswer: answers[q.id] || 'Not answered'
      };
    });

    return { score, correct, totalPoints, breakdown };
  };

  const { score, correct, totalPoints, breakdown } = calculateResults();
  const percentage = Math.round((score / totalPoints) * 100);

  const getPerformanceMessage = () => {
    if (percentage >= 90) return { text: "Outstanding!", color: "text-green-600", icon: Trophy };
    if (percentage >= 75) return { text: "Great Job!", color: "text-blue-600", icon: Award };
    if (percentage >= 50) return { text: "Well Done!", color: "text-yellow-600", icon: Award };
    return { text: "Keep Practicing!", color: "text-orange-600", icon: BarChart3 };
  };

  const message = getPerformanceMessage();
  const PerformanceIcon = message.icon;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Summary Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl overflow-hidden mb-8"
        >
          <div className="bg-blue-600 p-8 text-white text-center relative">
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
              <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
            </div>
            
            <h1 className="text-2xl font-bold mb-2">{SCHOOL_NAME}</h1>
            <p className="opacity-80 mb-6 uppercase tracking-widest text-sm font-semibold">Official Exam Result</p>
            
            <div className="relative inline-block">
              <div className="w-32 h-32 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md border-4 border-white/30 mx-auto">
                <div className="text-center">
                  <span className="text-4xl font-black">{percentage}%</span>
                </div>
              </div>
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute -top-2 -right-2 bg-yellow-400 text-yellow-900 w-10 h-10 rounded-full flex items-center justify-center shadow-lg"
              >
                <PerformanceIcon size={20} />
              </motion.div>
            </div>

            <h2 className={`text-2xl font-bold mt-4 ${message.color === 'text-green-600' ? 'text-green-100' : 'text-white'}`}>
              {message.text}
            </h2>
          </div>

          <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-6 rounded-2xl text-center">
              <p className="text-gray-500 text-sm font-semibold uppercase mb-1">Total Score</p>
              <p className="text-3xl font-bold text-gray-800">{score} / {totalPoints}</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-2xl text-center">
              <p className="text-gray-500 text-sm font-semibold uppercase mb-1">Correct Answers</p>
              <p className="text-3xl font-bold text-green-600">{correct} / {examQuestions.length}</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-2xl text-center">
              <p className="text-gray-500 text-sm font-semibold uppercase mb-1">Student Name</p>
              <p className="text-xl font-bold text-gray-800 truncate px-2">{studentInfo.name}</p>
            </div>
          </div>
        </motion.div>

        {/* Detailed Breakdown */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2 px-2">
            <BarChart3 size={24} className="text-blue-600" />
            Performance Breakdown
          </h3>
          
          {breakdown.map((q, idx) => (
            <motion.div 
              key={q.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-6 items-start"
            >
              <div className={`
                w-12 h-12 rounded-xl flex items-center justify-center shrink-0
                ${q.isCorrect ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}
              `}>
                {q.isCorrect ? <CheckCircle2 size={24} /> : <XCircle size={24} />}
              </div>
              
              <div className="flex-1">
                <p className="text-xs font-bold text-blue-600 uppercase mb-1">{q.part}</p>
                <p className="text-gray-800 font-bold mb-4 leading-tight">
                  {q.id}. {q.question || "Grammar/Vocabulary Completion"}
                </p>
                
                <div className="flex flex-wrap gap-4">
                  <div className="px-4 py-2 bg-gray-50 rounded-lg border border-gray-100">
                    <p className="text-[10px] text-gray-400 font-bold uppercase mb-1 tracking-tighter">Your Response</p>
                    <p className={`text-sm font-bold ${q.isCorrect ? 'text-green-600' : 'text-red-600'}`}>
                      {q.studentAnswer}
                    </p>
                  </div>
                  <div className={`px-4 py-2 rounded-lg border flex items-center gap-2 ${q.isCorrect ? 'bg-green-50 border-green-100 text-green-700' : 'bg-red-50 border-red-100 text-red-700'}`}>
                    <span className="text-xs font-black uppercase">{q.isCorrect ? 'Correct' : 'Incorrect'}</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <span className={`text-sm font-bold px-3 py-1 rounded-full ${q.isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                  {q.isCorrect ? `+${q.points}` : '0'} pts
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={onRestart}
            className="inline-flex items-center gap-2 bg-gray-800 text-white px-8 py-4 rounded-2xl font-bold hover:bg-gray-900 transition-all shadow-lg hover:shadow-xl active:scale-95"
          >
            <RefreshCw size={20} />
            Try Another Attempt
          </button>
        </div>
      </div>
    </div>
  );
};
