import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  DndContext, 
  DragEndEvent,
  PointerSensor,
  useSensor,
  useSensors,
  TouchSensor,
} from '@dnd-kit/core';
import { 
  ChevronLeft, 
  ChevronRight, 
  Flag, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Menu,
  X
} from 'lucide-react';
import { examQuestions, EXAM_DURATION, SCHOOL_NAME } from '../data';
import { StudentInfo, ExamState } from '../types';
import { formatTime } from '../utils';
import { DraggableWord, DroppableBlank } from './DnDComponents';

interface ExamProps {
  studentInfo: StudentInfo;
  onFinish: (answers: Record<number, string>) => void;
}

export const Exam: React.FC<ExamProps> = ({ studentInfo, onFinish }) => {
  const [state, setState] = useState<ExamState>({
    currentQuestionIndex: 0,
    answers: {},
    flagged: [],
    isSubmitted: false,
    timeLeft: EXAM_DURATION,
    startTime: Date.now(),
  });

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'flagged'>('all');

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(TouchSensor, {
      activationConstraint: {
        delay: 200,
        tolerance: 5,
      },
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && over.id === currentQuestion.blankId) {
      handleAnswer(active.id as string);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setState(prev => {
        if (prev.timeLeft <= 0) {
          clearInterval(timer);
          onFinish(prev.answers);
          return prev;
        }
        return { ...prev, timeLeft: prev.timeLeft - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [onFinish]);

  const currentQuestion = examQuestions[state.currentQuestionIndex];
  const progress = (Object.keys(state.answers).length / examQuestions.length) * 100;

  const handleAnswer = (answer: string) => {
    setState(prev => ({
      ...prev,
      answers: { ...prev.answers, [currentQuestion.id]: answer }
    }));
  };

  const toggleFlag = () => {
    setState(prev => {
      const isFlagged = prev.flagged.includes(currentQuestion.id);
      return {
        ...prev,
        flagged: isFlagged 
          ? prev.flagged.filter(id => id !== currentQuestion.id)
          : [...prev.flagged, currentQuestion.id]
      };
    });
  };

  const nextQuestion = () => {
    if (state.currentQuestionIndex < examQuestions.length - 1) {
      setState(prev => ({ ...prev, currentQuestionIndex: prev.currentQuestionIndex + 1 }));
    } else {
      setShowConfirmModal(true);
    }
  };

  const prevQuestion = () => {
    if (state.currentQuestionIndex > 0) {
      setState(prev => ({ ...prev, currentQuestionIndex: prev.currentQuestionIndex - 1 }));
    }
  };

  const goToQuestion = (index: number) => {
    setState(prev => ({ ...prev, currentQuestionIndex: index }));
    if (window.innerWidth < 1024) setShowSidebar(false);
  };

  const isLastQuestion = state.currentQuestionIndex === examQuestions.length - 1;
  const isQuestionAnswered = !!state.answers[currentQuestion.id];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowSidebar(!showSidebar)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              <Menu size={24} />
            </button>
            <div className="hidden md:block">
              <h1 className="text-lg font-bold text-blue-700">{SCHOOL_NAME}</h1>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">
                {studentInfo.name} | Section: {studentInfo.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full border border-blue-100">
              <Clock className="text-blue-600" size={18} />
              <span className={`font-mono font-bold ${state.timeLeft < 300 ? 'text-red-500 animate-pulse' : 'text-blue-700'}`}>
                {formatTime(state.timeLeft)}
              </span>
            </div>
            <button 
              onClick={() => setShowConfirmModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors hidden sm:block"
            >
              Submit Exam
            </button>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="h-1 bg-gray-100 w-full overflow-hidden">
          <motion.div 
            className="h-full bg-blue-500"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <aside className={`
          fixed lg:static inset-y-0 left-0 z-40 w-80 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
          ${showSidebar ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}>
          <div className="h-full flex flex-col p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-gray-800 flex items-center gap-2 text-sm uppercase tracking-wider">
                <CheckCircle2 size={18} className="text-blue-600" />
                Navigator
              </h2>
              <button onClick={() => setShowSidebar(false)} className="lg:hidden">
                <X size={20} />
              </button>
            </div>

            {/* Review Tabs */}
            <div className="flex border-b border-gray-100 mb-6">
              <button 
                onClick={() => setActiveTab('all')}
                className={`flex-1 py-2 text-xs font-bold transition-colors border-b-2 ${activeTab === 'all' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-400'}`}
              >
                All Questions
              </button>
              <button 
                onClick={() => setActiveTab('flagged')}
                className={`flex-1 py-2 text-xs font-bold transition-colors border-b-2 ${activeTab === 'flagged' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-400'}`}
              >
                To be Reviewed ({state.flagged.length})
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              <div className="grid grid-cols-5 gap-2">
                {examQuestions.map((q, idx) => {
                  const isCurrent = state.currentQuestionIndex === idx;
                  const isAnswered = !!state.answers[q.id];
                  const isFlagged = state.flagged.includes(q.id);
                  
                  // If we're on the flagged tab and this question isn't flagged, don't show it (or show it faded)
                  if (activeTab === 'flagged' && !isFlagged) return null;

                  let bgColor = 'bg-gray-50 text-gray-400 border-gray-200';
                  if (isAnswered) bgColor = 'bg-blue-600 text-white border-blue-600';
                  if (isFlagged) bgColor = 'bg-yellow-400 text-white border-yellow-400';
                  if (isCurrent) bgColor = 'bg-white text-blue-600 border-blue-600 ring-2 ring-blue-100 ring-offset-2';

                  return (
                    <button
                      key={q.id}
                      onClick={() => goToQuestion(idx)}
                      className={`
                        h-10 w-10 rounded-lg border-2 text-sm font-bold flex items-center justify-center transition-all
                        ${bgColor}
                      `}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
              {activeTab === 'flagged' && state.flagged.length === 0 && (
                <div className="text-center py-8">
                  <Flag className="mx-auto text-gray-200 mb-2" size={32} />
                  <p className="text-xs text-gray-400 font-medium">No flagged questions</p>
                </div>
              )}
            </div>

            <div className="mt-6 space-y-3 pt-6 border-t border-gray-100">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="w-4 h-4 rounded bg-blue-600"></div>
                <span>Answered</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="w-4 h-4 rounded bg-yellow-400"></div>
                <span>Flagged for Review</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <div className="w-4 h-4 rounded border-2 border-gray-200"></div>
                <span>Not Visited</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-3xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestion.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden"
              >
                <div className="p-6 md:p-8">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-blue-600 font-bold uppercase tracking-wider text-sm">
                      {currentQuestion.part}
                    </span>
                    <button
                      onClick={toggleFlag}
                      className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-semibold transition-colors
                        ${state.flagged.includes(currentQuestion.id) 
                          ? 'bg-yellow-100 text-yellow-700' 
                          : 'bg-gray-100 text-gray-500 hover:bg-yellow-50 hover:text-yellow-600'}
                      `}
                    >
                      <Flag size={14} fill={state.flagged.includes(currentQuestion.id) ? "currentColor" : "none"} />
                      {state.flagged.includes(currentQuestion.id) ? 'Flagged' : 'Mark for Review'}
                    </button>
                  </div>

                  <p className="text-gray-500 text-sm mb-4 italic font-medium">
                    {currentQuestion.instruction}
                  </p>

                  <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
                    {currentQuestion.wordBank && (
                      <div className="mb-8 p-6 bg-blue-50/50 border-2 border-dashed border-blue-200 rounded-2xl">
                        <p className="text-xs font-bold text-blue-400 uppercase mb-4 tracking-widest text-center">Word Bank</p>
                        <div className="flex flex-wrap justify-center gap-3">
                          {currentQuestion.wordBank.map((word) => {
                            const isUsedElsewhere = Object.entries(state.answers).some(([qId, ans]) => parseInt(qId) !== currentQuestion.id && ans === word);
                            const isSelectedHere = state.answers[currentQuestion.id] === word;
                            return (
                              <DraggableWord 
                                key={word} 
                                id={word} 
                                word={word} 
                                isSelected={isUsedElsewhere || isSelectedHere} 
                              />
                            );
                          })}
                        </div>
                        <p className="text-[10px] text-blue-300 text-center mt-4 uppercase font-bold tracking-tighter">Drag words to the blank below</p>
                      </div>
                    )}

                    {currentQuestion.text && (
                      <div className="bg-blue-50/30 p-6 rounded-xl mb-8 border border-blue-100 text-gray-800 leading-relaxed text-lg shadow-sm">
                        <div className="text-xs font-bold text-blue-400 uppercase mb-4 tracking-widest border-b border-blue-100 pb-2">Reading Passage / Grammar Context</div>
                        <div className="whitespace-pre-line space-y-4">
                          {currentQuestion.text}
                        </div>
                      </div>
                    )}

                    {currentQuestion.type === 'vocabulary' ? (
                      <div className="text-xl font-bold text-gray-800 mb-12 leading-loose p-6 bg-white border border-gray-100 rounded-2xl shadow-sm">
                        {currentQuestion.id}. {currentQuestion.question?.split('_______').map((part, index, array) => (
                          <span key={index}>
                            {part}
                            {index < array.length - 1 && (
                              <DroppableBlank 
                                id={currentQuestion.blankId || ''} 
                                currentAnswer={state.answers[currentQuestion.id]} 
                              />
                            )}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <h3 className="text-xl font-bold text-gray-800 mb-8 leading-tight">
                        {currentQuestion.id}. {currentQuestion.question}
                      </h3>
                    )}
                  </DndContext>

                  <div className="space-y-4">
                    {currentQuestion.type !== 'vocabulary' && currentQuestion.options?.map((option, idx) => {
                      const isSelected = state.answers[currentQuestion.id] === option;
                      return (
                        <button
                          key={idx}
                          onClick={() => handleAnswer(option)}
                          className={`
                            w-full text-left p-4 rounded-xl border-2 transition-all flex items-center gap-4 group
                            ${isSelected 
                              ? 'border-blue-600 bg-blue-50 ring-4 ring-blue-50' 
                              : 'border-gray-100 hover:border-blue-200 hover:bg-gray-50'}
                          `}
                        >
                          <div className={`
                            w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0
                            ${isSelected ? 'border-blue-600 bg-blue-600' : 'border-gray-300 group-hover:border-blue-400'}
                          `}>
                            {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                          </div>
                          <span className={`font-medium ${isSelected ? 'text-blue-900' : 'text-gray-700'}`}>
                            {option}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                  <div className="bg-gray-50 p-6 flex justify-between items-center border-t border-gray-100">
                  <button
                    onClick={prevQuestion}
                    disabled={state.currentQuestionIndex === 0}
                    className="flex items-center gap-2 text-gray-600 font-semibold disabled:opacity-30 disabled:cursor-not-allowed hover:text-blue-600 transition-colors"
                  >
                    <ChevronLeft size={20} />
                    Previous
                  </button>
                  <div className="flex flex-col items-end gap-1">
                    {!isQuestionAnswered && (
                      <span className="text-[10px] text-orange-500 font-bold uppercase tracking-tighter">Please answer to continue</span>
                    )}
                    <button
                      onClick={nextQuestion}
                      disabled={!isQuestionAnswered && !isLastQuestion}
                      className={`flex items-center gap-2 px-8 py-3 rounded-xl font-bold shadow-md transform active:scale-95 transition-all
                        ${isQuestionAnswered || isLastQuestion 
                          ? 'bg-blue-600 text-white hover:bg-blue-700' 
                          : 'bg-gray-200 text-gray-400 cursor-not-allowed'}
                      `}
                    >
                      {isLastQuestion ? 'Review & Submit' : 'Next Question'}
                      {!isLastQuestion && <ChevronRight size={20} />}
                    </button>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowConfirmModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl p-8 max-w-sm w-full relative z-10 shadow-2xl"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle size={32} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Ready to Submit?</h3>
                <p className="text-gray-500 mb-6">
                  You have answered {Object.keys(state.answers).length} out of {examQuestions.length} questions.
                  {state.flagged.length > 0 && ` You still have ${state.flagged.length} questions flagged for review.`}
                </p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={() => onFinish(state.answers)}
                    className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg"
                  >
                    Yes, Submit Exam
                  </button>
                  <button
                    onClick={() => setShowConfirmModal(false)}
                    className="w-full bg-gray-100 text-gray-600 py-3 rounded-xl font-bold hover:bg-gray-200 transition-colors"
                  >
                    Keep Working
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
