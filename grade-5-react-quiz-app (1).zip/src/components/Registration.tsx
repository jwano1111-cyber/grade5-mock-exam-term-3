import { useState } from 'react';
import { StudentInfo } from '../types';
import { SCHOOL_NAME, TEACHER_NAME } from '../data';
import { GraduationCap, User, IdCard, BookOpen } from 'lucide-react';

interface RegistrationProps {
  onStart: (info: StudentInfo) => void;
}

export const Registration: React.FC<RegistrationProps> = ({ onStart }) => {
  const [info, setInfo] = useState<StudentInfo>({
    name: '',
    grade: 'Grade 5',
    section: '',
    idNumber: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (info.name && info.section && info.idNumber) {
      onStart(info);
    }
  };

  return (
    <div className="min-h-screen bg-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="text-white w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">{SCHOOL_NAME}</h1>
          <p className="text-gray-500">Teacher: {TEACHER_NAME}</p>
          <div className="mt-2 inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-semibold">
            Term 3 Mock Exam
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
              <User size={16} /> Student Name
            </label>
            <input
              required
              type="text"
              value={info.name}
              onChange={(e) => setInfo({ ...info, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
              placeholder="Enter your full name"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                <BookOpen size={16} /> Grade
              </label>
              <input
                disabled
                type="text"
                value={info.grade}
                className="w-full px-4 py-2 border border-gray-200 bg-gray-50 rounded-lg text-gray-500 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
                <IdCard size={16} /> Section
              </label>
              <input
                required
                type="text"
                value={info.section}
                onChange={(e) => setInfo({ ...info, section: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="e.g. 5-A"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
              <IdCard size={16} /> Student ID
            </label>
            <input
              required
              type="text"
              value={info.idNumber}
              onChange={(e) => setInfo({ ...info, idNumber: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
              placeholder="Enter your ID number"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg shadow-lg transform active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            Start Exam
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-gray-400 uppercase tracking-widest font-semibold">
          Exam Duration: 90 Minutes
        </p>
      </div>
    </div>
  );
};
