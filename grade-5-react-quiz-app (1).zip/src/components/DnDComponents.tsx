import { useDraggable, useDroppable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';

interface DraggableWordProps {
  id: string;
  word: string;
}

interface DraggableWordProps {
  id: string;
  word: string;
  isSelected?: boolean;
}

export const DraggableWord = ({ id, word, isSelected }: DraggableWordProps) => {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: id,
    disabled: isSelected
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`
        px-4 py-2 border-2 rounded-xl shadow-sm transition-all flex items-center gap-2 font-bold
        ${isSelected 
          ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed opacity-60' 
          : 'bg-white border-blue-100 text-blue-700 cursor-grab active:cursor-grabbing hover:border-blue-300 hover:bg-blue-50'
        }
        ${isDragging ? 'z-50 ring-2 ring-blue-500' : ''}
      `}
    >
      {!isSelected && <GripVertical size={14} className="text-blue-300" />}
      {word}
    </div>
  );
};

interface DroppableBlankProps {
  id: string;
  currentAnswer?: string;
  placeholder?: string;
}

export const DroppableBlank = ({ id, currentAnswer, placeholder = '_______' }: DroppableBlankProps) => {
  const { isOver, setNodeRef } = useDroppable({
    id: id,
  });

  return (
    <span
      ref={setNodeRef}
      className={`
        inline-flex items-center justify-center min-w-[120px] h-10 px-4 mx-1 
        border-2 border-dashed rounded-lg transition-all
        ${isOver ? 'border-blue-500 bg-blue-50 scale-105' : 'border-gray-300 bg-gray-50'}
        ${currentAnswer ? 'border-solid border-blue-600 bg-white' : ''}
      `}
    >
      {currentAnswer ? (
        <span className="font-bold text-blue-800">{currentAnswer}</span>
      ) : (
        <span className="text-gray-400 text-sm font-medium italic">{placeholder}</span>
      )}
    </span>
  );
};
